/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.p.common;

/**
 *
 * @author Katherine
 */
public interface Pago {
    
    public boolean validar();
 public void procesar();
 public String obtenerDetalle();

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.p.plugin.bch;

import co.edu.unicauca.pagos.p.common.Pago;

/**
 *
 * @author Katherine
 */
public class PagoCriptomoneda implements Pago {
    private String direccionBilletera;
    private double monto;

    public PagoCriptomoneda(String direccionBilletera, double monto) {
        this.direccionBilletera = direccionBilletera;
        this.monto = monto;
    }


    public boolean validar() {
        return direccionBilletera != null && direccionBilletera.startsWith("0x");
    }

    public void procesar() {
        if (validar()) {
            System.out.println("Pago con criptomonedas procesado: " + monto);
        } else {
            System.out.println("Dirección de billetera inválida.");
        }
    }

  
    public String obtenerDetalle() {
        return "Pago con criptomonedas - Monto: " + monto;
    }
}

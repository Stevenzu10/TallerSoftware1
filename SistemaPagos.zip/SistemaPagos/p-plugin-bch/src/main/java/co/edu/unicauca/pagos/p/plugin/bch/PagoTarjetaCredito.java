/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.p.plugin.bch;

import co.edu.unicauca.pagos.p.common.Pago;

/**
 *
 * @author Katherine
 */
public class PagoTarjetaCredito implements Pago {
    private String numeroTarjeta;
    private double monto;

    public PagoTarjetaCredito(String numeroTarjeta, double monto) {
        this.numeroTarjeta = numeroTarjeta;
        this.monto = monto;
    }

    public boolean validar() {
        return numeroTarjeta != null && numeroTarjeta.length() == 16;
    }

    public void procesar() {
        if (validar()) {
            System.out.println("Pago con tarjeta procesado: " + monto);
        } else {
            System.out.println("Número de tarjeta inválido.");
        }
    }

    public String obtenerDetalle() {
        return "Pago con tarjeta de crédito - Monto: " + monto;
    }
}

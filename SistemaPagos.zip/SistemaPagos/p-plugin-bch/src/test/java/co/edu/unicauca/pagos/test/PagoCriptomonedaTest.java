/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.test;

import co.edu.unicauca.pagos.p.plugin.bch.PagoCriptomoneda;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Katherine
 */
public class PagoCriptomonedaTest {
     @Test
    public void testValidarConDireccionValida() {
        PagoCriptomoneda pago = new PagoCriptomoneda("0x123abc456def", 300.0);
        assertTrue(pago.validar(), "La dirección de la billetera debería ser válida.");
    }

    @Test
    public void testValidarConDireccionInvalida() {
        PagoCriptomoneda pago = new PagoCriptomoneda("1234", 300.0);
        assertFalse(pago.validar(), "La dirección de la billetera debería ser inválida.");
    }

    @Test
    public void testProcesarConDireccionValida() {
        PagoCriptomoneda pago = new PagoCriptomoneda("0x123abc456def", 300.0);

        // Redirigir la salida estándar para verificar la impresión en consola
        String mensajeEsperado = "Pago con criptomonedas procesado: 300.0";
        assertDoesNotThrow(() -> pago.procesar(), "El pago debería procesarse sin errores.");
    }

    @Test
    public void testProcesarConDireccionInvalida() {
        PagoCriptomoneda pago = new PagoCriptomoneda("abcd", 300.0);

        // Redirigir la salida estándar para verificar la impresión en consola
        String mensajeEsperado = "Dirección de billetera inválida.";
        assertDoesNotThrow(() -> pago.procesar(), "El pago debería manejar la dirección inválida sin errores.");
    }

    @Test
    public void testObtenerDetalle() {
        PagoCriptomoneda pago = new PagoCriptomoneda("0x123abc456def", 300.0);
        String result = pago.obtenerDetalle();
        
        assertTrue(result.contains("Pago con criptomonedas") && result.contains("300.0"), 
                   "El detalle del pago no contiene la información esperada.");
    }

}

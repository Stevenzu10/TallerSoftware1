/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.test;

import co.edu.unicauca.pagos.p.plugin.bch.PagoTarjetaCredito;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Katherine
 */
public class PagoTarjetaCreditoTest {
 @Test
    public void testValidarTarjetaCorrecta() {
        PagoTarjetaCredito pago = new PagoTarjetaCredito("1234567812345678", 150.0);
        assertTrue(pago.validar(), "La tarjeta debería ser válida.");
    }

    @Test
    public void testValidarTarjetaIncorrecta() {
        PagoTarjetaCredito pago = new PagoTarjetaCredito("123", 150.0);
        assertFalse(pago.validar(), "La tarjeta debería ser inválida.");
    }

    @Test
    public void testProcesarConTarjetaValida() {
        PagoTarjetaCredito pago = new PagoTarjetaCredito("1234567812345678", 150.0);
        
        // Verificamos que el método se ejecuta sin errores
        assertDoesNotThrow(() -> pago.procesar(), "El procesamiento debería ejecutarse sin errores.");
    }

    @Test
    public void testProcesarConTarjetaInvalida() {
        PagoTarjetaCredito pago = new PagoTarjetaCredito("0000", 150.0);
        
        // Verificamos que el método se ejecuta sin errores, aunque no sea válido
        assertDoesNotThrow(() -> pago.procesar(), "El procesamiento debería manejar la tarjeta inválida sin errores.");
    }

    @Test
    public void testObtenerDetalle() {
        PagoTarjetaCredito pago = new PagoTarjetaCredito("1234567812345678", 150.0);
        String result = pago.obtenerDetalle();
        
        assertTrue(result.contains("Pago con tarjeta de crédito") && result.contains("150.0"), 
                   "El detalle del pago no contiene la información esperada.");
    }

}

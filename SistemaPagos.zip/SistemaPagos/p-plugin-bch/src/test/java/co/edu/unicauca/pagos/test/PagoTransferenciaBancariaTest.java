/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.test;

import co.edu.unicauca.pagos.p.plugin.bch.PagoTransferenciaBancaria;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Katherine
 */
public class PagoTransferenciaBancariaTest {
  @Test
    public void testValidarCuentaCorrecta() {
        PagoTransferenciaBancaria pago = new PagoTransferenciaBancaria("1234567890", 200.0);
        assertTrue(pago.validar(), "La cuenta bancaria debería ser válida.");
    }

    @Test
    public void testValidarCuentaIncorrecta() {
        PagoTransferenciaBancaria pago = new PagoTransferenciaBancaria("12345", 200.0);
        assertFalse(pago.validar(), "La cuenta bancaria debería ser inválida.");
    }

    @Test
    public void testProcesarConCuentaValida() {
        PagoTransferenciaBancaria pago = new PagoTransferenciaBancaria("1234567890", 200.0);
        
        // Verificamos que el método se ejecuta sin errores
        assertDoesNotThrow(() -> pago.procesar(), "El procesamiento debería ejecutarse sin errores.");
    }

    @Test
    public void testProcesarConCuentaInvalida() {
        PagoTransferenciaBancaria pago = new PagoTransferenciaBancaria("1234", 200.0);
        
        // Verificamos que el método se ejecuta sin errores, aunque no sea válido
        assertDoesNotThrow(() -> pago.procesar(), "El procesamiento debería manejar la cuenta inválida sin errores.");
    }

    @Test
    public void testObtenerDetalle() {
        PagoTransferenciaBancaria pago = new PagoTransferenciaBancaria("1234567890", 200.0);
        String result = pago.obtenerDetalle();
        
        assertTrue(result.contains("Pago por transferencia bancaria") && result.contains("200.0"), 
                   "El detalle del pago no contiene la información esperada.");
    }

}
